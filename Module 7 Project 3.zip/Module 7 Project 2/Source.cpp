#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include<iomanip>	

class ItemTracker {

private:

	std::map<std::string, int> itemFrequency;

	void loadItems(const std::string& filename) {
		std::ifstream inputFile(filename);
		std::string item;
		while (inputFile >> item) {
			itemFrequency[item]++;
		}
		inputFile.close();
	}

public:

	ItemTracker(const std::string& filename) {
		loadItems(filename);
		backupData("frequency.dat");
	}
	//function for searching items
	int searchItem(const std::string& item) const {
		auto it = itemFrequency.find(item);
		if (it != itemFrequency.end()) {
			return it->second;
		}
		else {
			return 0;
		}

	}
	//function for displaying iem info
	void displayitems() const {
		for (const auto& pair : itemFrequency) {
			std::cout << pair.first << " " << pair.second << std::endl;
		}
	}
	//function for printing histogram of data
	void printHistogram() const {
		for (const auto& pair : itemFrequency) {
			std::cout << std::setw(12) << std::left << pair.first << " ";
			for (int i = 0; i < pair.second; ++i) {
				std::cout << "*";
			}
			std::cout << std::endl;
		}
	}
	//backing up data to file
	void backupData(const std::string& filename) const {
		std::ofstream outputFile(filename);
		for (const auto& pair : itemFrequency) {
			outputFile << pair.first << " " << pair.second << std::endl;
		}
		outputFile.close();
	}
};

//function to display menu

void displayMenu() {
	std::cout << "\n--- Corner Grocer Menu ---\n";
	std::cout << "1. Search for an item\n";
	std::cout << "2. Display all items\n";
	std::cout << "3. Print histogram\n";
	std::cout << "4. Exit\n";
	std::cout << "Enter your choice: ";
}

int main() {
	ItemTracker tracker("CS210_Project_Three_Input_File.txt");

	int choice;
	do { //starting d0-while loop tomaintain menu while program is runnning
		displayMenu();
		std::cin >> choice;

		if (choice == 1) {
			std::string item;
			std::cout << "Enter the item to search for: ";
			std::cin >> item;
			int frequency = tracker.searchItem(item);
			if (frequency > 0) {
				std::cout << item << " purchased " << frequency << " times.\n";
			}
			else {
				std::cout << item << " not found in the records.\n";
			}
		}
		else if (choice == 2) {
			tracker.displayitems();
		}
		else if (choice == 3) {
			tracker.printHistogram();
		}
		else if (choice == 4) {
			std::cout << "Exiting program. Have a great day!\n";
		}
		else {
			std::cout << "Invalid selection, try again.\n"; //logic for invalid selection
		}
	} while (choice != 4); //used to continue the menu loop until exit is deired

	return 0;
}